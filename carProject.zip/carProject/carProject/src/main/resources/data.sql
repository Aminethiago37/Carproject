INSERT INTO voiture (model, color, matricul, price) VALUES ('ModelX', 'Red', '1234ABC', 50000);
INSERT INTO voiture (model, color, matricul, price) VALUES ('ModelY', 'Blue', '5678DEF', 40000);
INSERT INTO voiture (model, color, matricul, price) VALUES ('ModelZ', 'Green', '9101GHI', 60000);
INSERT INTO voiture (model, color, matricul, price) VALUES ('ModelA', 'Black', '1123JKL', 70000);
