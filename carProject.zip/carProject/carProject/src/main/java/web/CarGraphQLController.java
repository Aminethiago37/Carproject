package web;


import service.CarService;
import dto.CarDTO;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.stereotype.Controller;

@Controller
public class CarGraphQLController {
    private final CarService carService;

    public CarGraphQLController(CarService carService) {
        this.carService = carService;
    }

    @QueryMapping
    public CarDTO getCarByModel(String model) {
        return carService.getCarByModel(model);
    }

    @MutationMapping
    public CarDTO saveCar(CarDTO car) {
        return carService.saveCar(car);
    }
}

