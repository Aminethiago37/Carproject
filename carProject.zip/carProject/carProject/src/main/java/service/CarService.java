package service;


import dto.CarDTO;

public interface CarService {
    CarDTO getCarByModel(String model);
    CarDTO saveCar(CarDTO car);
}

