package service;

import dao.CarRepository;
import dto.CarDTO;
import mapper.CarMapper;
import model.Voiture;
import org.springframework.stereotype.Service;

@Service
public class CarManager implements CarService {
    private final CarRepository carRepository;
    private final CarMapper carMapper;

    public CarManager(CarRepository carRepository, CarMapper carMapper) {
        this.carRepository = carRepository;
        this.carMapper = carMapper;
    }

    @Override
    public CarDTO getCarByModel(String model) {
        Voiture voiture = carRepository.findByModel(model);
        return carMapper.toDTO(voiture);
    }

    @Override
    public CarDTO saveCar(CarDTO car) {
        Voiture voiture = carMapper.toEntity(car);
        Voiture savedCar = carRepository.save(voiture);
        return carMapper.toDTO(savedCar);
    }
}

