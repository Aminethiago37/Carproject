package mapper;

import dto.CarDTO;
import model.Voiture;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@Component
public class CarMapper {
    private final ModelMapper modelMapper = new ModelMapper();

    public CarDTO toDTO(Voiture voiture) {
        return modelMapper.map(voiture, CarDTO.class);
    }

    public Voiture toEntity(CarDTO carDTO) {
        return modelMapper.map(carDTO, Voiture.class);
    }
}

