package dao;


import model.Voiture;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CarRepository extends JpaRepository<Voiture, Long> {
    Voiture findByModel(String model);
}

