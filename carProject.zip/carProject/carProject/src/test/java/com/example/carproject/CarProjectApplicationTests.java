package com.example.carproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
